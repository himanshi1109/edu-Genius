const SkeletonLoader = ({
  width = '100%',
  height = '20px',
  borderRadius = '8px',
  lines = 1,
  className = '',
}) => {
  if (lines > 1) {
    return (
      <div className={`space-y-3 ${className}`}>
        {Array.from({ length: lines }).map((_, i) => (
          <div
            key={i}
            className="skeleton"
            style={{
              width: i === lines - 1 ? '60%' : width,
              height,
              borderRadius,
            }}
          />
        ))}
      </div>
    );
  }

  return (
    <div
      className={`skeleton ${className}`}
      style={{ width, height, borderRadius }}
    />
  );
};

export const SkeletonCard = ({ className = '' }) => (
  <div className={`glass-card p-6 space-y-4 ${className}`}>
    <SkeletonLoader height="160px" borderRadius="12px" />
    <SkeletonLoader height="14px" width="40%" />
    <SkeletonLoader height="20px" width="80%" />
    <SkeletonLoader height="14px" lines={2} />
    <div className="flex gap-3 mt-4">
      <SkeletonLoader height="36px" width="100px" borderRadius="12px" />
      <SkeletonLoader height="36px" width="100px" borderRadius="12px" />
    </div>
  </div>
);

export default SkeletonLoader;
