import { motion } from 'framer-motion';
import { cn } from '@/utils/helpers';

const GlowCard = ({
  children,
  className = '',
  glowColor = 'blue',
  hover = true,
  onClick,
  ...props
}) => {
  const glowMap = {
    blue: 'rgba(59, 130, 246, 0.15)',
    purple: 'rgba(139, 92, 246, 0.15)',
    cyan: 'rgba(6, 182, 212, 0.15)',
    green: 'rgba(34, 197, 94, 0.15)',
  };

  return (
    <motion.div
      className={cn('glass-card p-6', className)}
      whileHover={
        hover
          ? {
              y: -4,
              boxShadow: `0 0 20px ${glowMap[glowColor] || glowMap.blue}, 0 8px 32px rgba(0,0,0,0.3)`,
              borderColor: 'rgba(59, 130, 246, 0.4)',
              transition: { type: 'spring', stiffness: 400, damping: 25 },
            }
          : {}
      }
      onClick={onClick}
      {...props}
    >
      {children}
    </motion.div>
  );
};

export default GlowCard;
