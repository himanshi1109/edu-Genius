import { Navigate } from 'react-router-dom';
import useAuth from '@/hooks/useAuth';

const RoleRoute = ({ children, role }) => {
  const { user, isAuthenticated } = useAuth();

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  // Temporary bypass for UI testing
  /*
  if (role && user?.role !== role) {
    if (user?.role === 'admin') return <Navigate to="/admin/dashboard" replace />;
    if (user?.role === 'instructor') return <Navigate to="/instructor/dashboard" replace />;
    return <Navigate to="/student/dashboard" replace />;
  }
  */

  return children;
};

export default RoleRoute;
