import { lazy, Suspense } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { AnimatePresence } from 'framer-motion';
import { useLocation } from 'react-router-dom';
import useAuth from '@/hooks/useAuth';
import Layout from '@/components/layout/Layout';
import ProtectedRoute from './ProtectedRoute';
import RoleRoute from './RoleRoute';

/* Lazy-load pages */
const Landing = lazy(() => import('@/pages/Landing'));
const Login = lazy(() => import('@/pages/Login'));
const Register = lazy(() => import('@/pages/Register'));
const CourseCatalog = lazy(() => import('@/pages/student/CourseCatalog'));
const CourseDetail = lazy(() => import('@/pages/student/CourseDetail'));
const StudentDashboard = lazy(() => import('@/pages/student/StudentDashboard'));
const LearningWorkspace = lazy(() => import('@/pages/student/LearningWorkspace'));
const QuizPage = lazy(() => import('@/pages/student/QuizPage'));
const FlashcardsPage = lazy(() => import('@/pages/student/FlashcardsPage'));
const ProgressTracker = lazy(() => import('@/pages/student/ProgressTracker'));
const CertificatePage = lazy(() => import('@/pages/student/CertificatePage'));
const InstructorDashboard = lazy(() => import('@/pages/instructor/InstructorDashboard'));
const CourseBuilder = lazy(() => import('@/pages/instructor/CourseBuilder'));
const ModuleBuilder = lazy(() => import('@/pages/instructor/ModuleBuilder'));
const ProfileSettings = lazy(() => import('@/pages/shared/ProfileSettings'));
const AdminDashboard = lazy(() => import('@/pages/admin/AdminDashboard'));
const CourseApprovals = lazy(() => import('@/pages/admin/CourseApprovals'));
const UserManagement = lazy(() => import('@/pages/admin/UserManagement'));

const PageLoader = () => (
  <div className="flex items-center justify-center min-h-screen">
    <div className="w-10 h-10 border-2 border-[var(--accent-blue)] border-t-transparent rounded-full animate-spin" />
  </div>
);

const DashboardRedirect = () => {
  const { user } = useAuth();
  if (user?.role === 'admin') {
    return <Navigate to="/admin/dashboard" replace />;
  }
  if (user?.role === 'instructor') {
    return <Navigate to="/instructor/dashboard" replace />;
  }
  return <Navigate to="/student/dashboard" replace />;
};

const AppRouter = () => {
  const location = useLocation();

  return (
    <Suspense fallback={<PageLoader />}>
      <AnimatePresence mode="wait">
        <Routes location={location} key={location.pathname}>
          {/* Public routes — no sidebar */}
          <Route path="/" element={<Landing />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />

          {/* Dashboard redirect */}
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <DashboardRedirect />
              </ProtectedRoute>
            }
          />

          {/* Protected routes with Layout (sidebar) */}
          <Route
            element={
              <ProtectedRoute>
                <Layout />
              </ProtectedRoute>
            }
          >
            {/* Student routes */}
            <Route
              path="/student/dashboard"
              element={
                <RoleRoute role="student">
                  <StudentDashboard />
                </RoleRoute>
              }
            />
            <Route path="/courses" element={<CourseCatalog />} />
            <Route path="/courses/:id" element={<CourseDetail />} />
            <Route
              path="/student/learn/:id"
              element={
                <RoleRoute role="student">
                  <LearningWorkspace />
                </RoleRoute>
              }
            />
            <Route path="/student/quiz/:lessonId" element={<RoleRoute role="student"><QuizPage /></RoleRoute>} />
            <Route path="/student/course-quiz/:courseId" element={<RoleRoute role="student"><QuizPage /></RoleRoute>} />
            <Route path="/student/flashcards/:lessonId" element={<RoleRoute role="student"><FlashcardsPage /></RoleRoute>} />
            <Route path="/student/course-flashcards/:courseId" element={<RoleRoute role="student"><FlashcardsPage /></RoleRoute>} />
            <Route path="/student/progress/:id" element={<RoleRoute role="student"><ProgressTracker /></RoleRoute>} />
            <Route
              path="/student/certificate/:id"
              element={
                <RoleRoute role="student">
                  <CertificatePage />
                </RoleRoute>
              }
            />

            {/* Instructor routes */}
            <Route
              path="/instructor/dashboard"
              element={
                <RoleRoute role="instructor">
                  <InstructorDashboard />
                </RoleRoute>
              }
            />
            <Route
              path="/instructor/courses/new"
              element={
                <RoleRoute role="instructor">
                  <CourseBuilder />
                </RoleRoute>
              }
            />
            <Route
              path="/instructor/courses/:id/edit"
              element={
                <RoleRoute role="instructor">
                  <CourseBuilder />
                </RoleRoute>
              }
            />
            <Route
              path="/instructor/modules/:courseId"
              element={
                <RoleRoute role="instructor">
                  <ModuleBuilder />
                </RoleRoute>
              }
            />

            {/* Admin routes */}
            <Route
              path="/admin/dashboard"
              element={
                <RoleRoute role="admin">
                  <AdminDashboard />
                </RoleRoute>
              }
            />
            <Route
              path="/admin/approvals"
              element={
                <RoleRoute role="admin">
                  <CourseApprovals />
                </RoleRoute>
              }
            />
            <Route
              path="/admin/users"
              element={
                <RoleRoute role="admin">
                  <UserManagement />
                </RoleRoute>
              }
            />

            {/* Shared routes */}
            <Route path="/profile" element={<ProfileSettings />} />
          </Route>

          {/* Catch all */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </AnimatePresence>
    </Suspense>
  );
};

export default AppRouter;
