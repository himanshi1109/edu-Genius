import { Navigate } from 'react-router-dom';
import useAuth from '@/hooks/useAuth';

const ProtectedRoute = ({ children }) => {
  const { isAuthenticated } = useAuth();

  // Temporary bypass for UI testing
  /*
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  */

  return children;
};

export default ProtectedRoute;
