import api from './api';

const certificateService = {
  generateCertificate: async (courseId) => {
    const response = await api.post(`/certificates/${courseId}`);
    return response.data;
  },

  getCertificate: async (courseId) => {
    const response = await api.get(`/certificates/${courseId}`);
    return response.data;
  },

  issueCertificate: async (courseId, studentId) => {
    const response = await api.post(`/certificates/issue/${courseId}`, { studentId });
    return response.data;
  },
};

export default certificateService;
