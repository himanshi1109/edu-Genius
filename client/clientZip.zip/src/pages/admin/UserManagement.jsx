import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { motion } from 'framer-motion';
import { fetchAllUsers, updateUserRole, deleteUser } from '@/store/slices/userSlice';
import { addToast } from '@/store/slices/uiSlice';
import GlowCard from '@/components/ui/GlowCard';
import EditUserModal from '@/components/admin/EditUserModal';
import { Users, Search, Edit2, Trash2 } from 'lucide-react';

const pageV = { initial: { opacity: 0, y: 20 }, animate: { opacity: 1, y: 0 }, exit: { opacity: 0, y: -20 } };

const UserManagement = () => {
  const dispatch = useDispatch();
  const { usersList, isLoading } = useSelector(s => s.users || {});
  const [searchTerm, setSearchTerm] = useState('');
  const [editModal, setEditModal] = useState({ isOpen: false, user: null });

  useEffect(() => {
    dispatch(fetchAllUsers());
  }, [dispatch]);

  const filteredUsers = (Array.isArray(usersList) ? usersList : []).filter(u => 
    u.name?.toLowerCase().includes(searchTerm.toLowerCase()) || 
    u.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleUpdate = async (updatedData) => {
    const res = await dispatch(updateUserRole(updatedData));
    setEditModal({ isOpen: false, user: null });
    if (updateUserRole.fulfilled.match(res)) {
      dispatch(addToast({ message: 'User updated successfully', type: 'success' }));
    } else {
      dispatch(addToast({ message: res.payload || 'Failed to update user', type: 'error' }));
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this user? This action cannot be undone.')) return;
    const res = await dispatch(deleteUser(id));
    if (deleteUser.fulfilled.match(res)) {
      dispatch(addToast({ message: 'User deleted', type: 'success' }));
    } else {
      dispatch(addToast({ message: res.payload || 'Failed to delete', type: 'error' }));
    }
  };

  return (
    <motion.div variants={pageV} initial="initial" animate="animate" exit="exit" className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="font-heading text-3xl font-bold text-[var(--text-primary)]">User Management</h1>
          <p className="text-[var(--text-muted)] mt-1">Manage accounts, roles, and access.</p>
        </div>
        
        <div className="relative w-full md:w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--text-muted)]" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search users..."
            className="input-glass w-full pl-9"
          />
        </div>
      </div>

      <GlowCard className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-[var(--border)] bg-[var(--surface-light)] text-[var(--text-secondary)] text-sm font-medium">
                <th className="px-6 py-4">User</th>
                <th className="px-6 py-4">Email</th>
                <th className="px-6 py-4">Role</th>
                <th className="px-6 py-4">Joined</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--border)]">
              {isLoading ? (
                <tr>
                  <td colSpan="5" className="px-6 py-12 text-center text-[var(--text-muted)]">
                    <div className="inline-block w-6 h-6 border-2 border-[#8b5cf6] border-t-transparent rounded-full animate-spin" />
                  </td>
                </tr>
              ) : filteredUsers.length === 0 ? (
                <tr>
                  <td colSpan="5" className="px-6 py-12 text-center text-[var(--text-muted)]">
                    No users found matching "{searchTerm}"
                  </td>
                </tr>
              ) : (
                filteredUsers.map(u => (
                  <tr key={u._id} className="hover:bg-[var(--surface-light)] transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#8b5cf6] to-[#6d28d9] flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                          {u.name?.charAt(0) || 'U'}
                        </div>
                        <span className="font-medium text-[var(--text-primary)]">{u.name}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-[var(--text-muted)]">{u.email}</td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium capitalize ${
                        u.role === 'admin' ? 'bg-[#8b5cf6]/10 text-[#8b5cf6]' :
                        u.role === 'instructor' ? 'bg-[var(--accent-blue)]/10 text-[var(--accent-blue)]' :
                        'bg-[var(--surface)] text-[var(--text-secondary)]'
                      }`}>
                        {u.role}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-[var(--text-muted)]">
                      {new Date(u.createdAt).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button 
                          onClick={() => setEditModal({ isOpen: true, user: u })}
                          className="p-2 text-[var(--text-muted)] hover:text-[#8b5cf6] rounded-lg hover:bg-[#8b5cf6]/10 transition-colors"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => handleDelete(u._id)}
                          className="p-2 text-[var(--text-muted)] hover:text-red-400 rounded-lg hover:bg-red-500/10 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </GlowCard>

      <EditUserModal
        isOpen={editModal.isOpen}
        onClose={() => setEditModal({ isOpen: false, user: null })}
        user={editModal.user}
        onSubmit={handleUpdate}
      />
    </motion.div>
  );
};

export default UserManagement;
