import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { motion } from 'framer-motion';
import { fetchCourses, adminDeleteCourse } from '@/store/slices/courseSlice';
import { fetchAllUsers } from '@/store/slices/userSlice';
import { getGreeting } from '@/utils/helpers';
import StatCard from '@/components/shared/StatCard';
import GlowCard from '@/components/ui/GlowCard';
import { Users, BookOpen, Clock, ShieldCheck, Pencil, Trash2 } from 'lucide-react';

const pageV = { initial: { opacity: 0, y: 20 }, animate: { opacity: 1, y: 0 }, exit: { opacity: 0, y: -20 } };

const AdminDashboard = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { user } = useSelector(s => s.auth || {});
  const { courses, pendingCourses } = useSelector(s => s.courses || {});
  const { usersList } = useSelector(s => s.users || {});

  useEffect(() => {
    dispatch(fetchCourses());
    dispatch(fetchAllUsers());
  }, [dispatch]);

  const approvedCount = Array.isArray(courses) ? courses.filter(c => c.status === 'approved' || !c.status).length : 0;

  const handleDeleteCourse = async (id) => {
    if (!window.confirm('Are you sure you want to delete this course? This action cannot be undone.')) return;
    await dispatch(adminDeleteCourse(id));
    dispatch(fetchCourses());
  };

  return (
    <motion.div variants={pageV} initial="initial" animate="animate" exit="exit" className="space-y-8">
      {/* Welcome */}
      <GlowCard className="p-8 relative overflow-hidden border-[#8b5cf6]/20">
        <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-bl from-[#8b5cf6]/20 to-transparent rounded-full -translate-y-1/2 translate-x-1/4" />
        <h1 className="font-heading text-3xl font-bold text-[var(--text-primary)] relative z-10">
          {getGreeting()}, Admin {user?.name?.split(' ')[0] || 'User'} 🛡️
        </h1>
        <p className="text-[var(--text-muted)] mt-2 relative z-10 max-w-xl">
          Welcome to the EduGenius control center. Monitor platform activity, manage users, and review course submissions.
        </p>
      </GlowCard>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Total Users" value={usersList?.length || 0} icon="Users" trend={12} />
        <StatCard title="Total Courses" value={courses?.length || 0} icon="BookOpen" trend={8} />
        <StatCard title="Pending Approvals" value={pendingCourses?.length || 0} icon="Clock" />
        <StatCard title="Approved Courses" value={approvedCount} icon="ShieldCheck" />
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <GlowCard className="p-6">
          <h2 className="font-heading text-xl font-semibold mb-4 text-[var(--text-primary)]">Recent Courses</h2>
          <div className="space-y-4">
            {(Array.isArray(courses) ? courses : []).slice(0, 5).map(course => (
              <div key={course._id} className="flex items-center justify-between p-3 rounded-xl bg-[var(--surface-light)] border border-[var(--border)]">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-[#8b5cf6]/10 flex items-center justify-center">
                    <BookOpen className="w-5 h-5 text-[#8b5cf6]" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-[var(--text-primary)]">{course.title}</p>
                    <p className="text-xs text-[var(--text-muted)]">{course.instructor?.name || 'Unknown'}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="text-xs font-medium px-2 py-1 rounded-full bg-[#8b5cf6]/10 text-[#8b5cf6] mr-2">
                    {course.status || 'approved'}
                  </div>
                  <button onClick={() => navigate(`/instructor/courses/${course._id}/edit`)} className="p-1.5 text-[var(--text-muted)] hover:text-[#8b5cf6] rounded-lg hover:bg-[#8b5cf6]/10 transition-colors" title="Edit Course">
                    <Pencil className="w-4 h-4" />
                  </button>
                  <button onClick={() => handleDeleteCourse(course._id)} className="p-1.5 text-[var(--text-muted)] hover:text-red-400 rounded-lg hover:bg-red-500/10 transition-colors" title="Delete Course">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
            {courses?.length === 0 && (
              <p className="text-sm text-[var(--text-muted)] text-center py-4">No courses available.</p>
            )}
          </div>
        </GlowCard>

        <GlowCard className="p-6">
          <h2 className="font-heading text-xl font-semibold mb-4 text-[var(--text-primary)]">Recent Users</h2>
          <div className="space-y-4">
            {(Array.isArray(usersList) ? usersList : []).slice(0, 5).map(u => (
              <div key={u._id} className="flex items-center justify-between p-3 rounded-xl bg-[var(--surface-light)] border border-[var(--border)]">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#8b5cf6] to-[#6d28d9] flex items-center justify-center text-white font-bold text-sm">
                    {u.name?.charAt(0) || 'U'}
                  </div>
                  <div>
                    <p className="text-sm font-medium text-[var(--text-primary)]">{u.name}</p>
                    <p className="text-xs text-[var(--text-muted)]">{u.email}</p>
                  </div>
                </div>
                <div className="text-xs font-medium px-2 py-1 rounded-full bg-[var(--surface)] text-[var(--text-secondary)] capitalize">
                  {u.role}
                </div>
              </div>
            ))}
            {usersList?.length === 0 && (
              <p className="text-sm text-[var(--text-muted)] text-center py-4">No users available.</p>
            )}
          </div>
        </GlowCard>
      </div>
    </motion.div>
  );
};

export default AdminDashboard;
