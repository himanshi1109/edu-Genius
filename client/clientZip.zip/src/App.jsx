import { useEffect } from 'react';
import { useDispatch } from 'react-redux';
import AppRouter from './router/AppRouter';
import { fetchMe } from './store/slices/authSlice';
import useAuth from './hooks/useAuth';

const App = () => {
  const dispatch = useDispatch();
  const { token } = useAuth();

  useEffect(() => {
    if (token) {
      dispatch(fetchMe());
    }
  }, [dispatch, token]);

  return <AppRouter />;
};

export default App;
